// ============================================================
// main.js — SmartLife Pro — Processus principal Electron
// ============================================================

'use strict';

const { app, BrowserWindow, Menu, ipcMain, shell } = require('electron');
const path = require('path');

// ===== CONFIGURATION FENÊTRE =====
let mainWindow = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 1024,
    minHeight: 680,
    title: 'SmartLife Pro',
    backgroundColor: '#0D0D0F',
    show: false, // Afficher après chargement pour éviter le flash blanc
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,        // Sécurité : désactivé
      contextIsolation: true,        // Sécurité : activé
      enableRemoteModule: false,     // Sécurité : désactivé
      webSecurity: true,
      allowRunningInsecureContent: false,
      sandbox: false                 // Nécessaire pour le preload
    },
    // Frameless ou natif selon la plateforme
    frame: true,
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    icon: path.join(__dirname, 'assets', process.platform === 'win32' ? 'icon.ico' : 'icon.png')
  });

  // ===== CHARGEMENT DU FICHIER HTML =====
  mainWindow.loadFile('index.html');

  // ===== AFFICHAGE PROPRE =====
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    // Optionnel : ouvrir DevTools en développement
    // if (process.env.NODE_ENV === 'development') {
    //   mainWindow.webContents.openDevTools();
    // }
  });

  // ===== CONTENT SECURITY POLICY =====
  mainWindow.webContents.session.webRequest.onHeadersReceived((details, callback) => {
    callback({
      responseHeaders: {
        ...details.responseHeaders,
        'Content-Security-Policy': [
          "default-src 'self'; " +
          "script-src 'self' 'unsafe-inline'; " +
          "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
          "font-src 'self' https://fonts.gstatic.com; " +
          "img-src 'self' data:; " +
          "connect-src 'none';"
        ]
      }
    });
  });

  // ===== GESTION FERMETURE =====
  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // ===== BLOCAGE NAVIGATION EXTERNE =====
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (url !== mainWindow.webContents.getURL()) {
      event.preventDefault();
    }
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

// ===== MENU NATIF =====
function buildMenu() {
  const isMac = process.platform === 'darwin';

  const template = [
    // Menu Application (Mac uniquement)
    ...(isMac ? [{
      label: app.name,
      submenu: [
        { role: 'about', label: 'À propos de SmartLife Pro' },
        { type: 'separator' },
        { role: 'services' },
        { type: 'separator' },
        { role: 'hide', label: 'Masquer SmartLife Pro' },
        { role: 'hideOthers', label: 'Masquer les autres' },
        { role: 'unhide', label: 'Tout afficher' },
        { type: 'separator' },
        { role: 'quit', label: 'Quitter SmartLife Pro' }
      ]
    }] : []),

    // Menu Fichier
    {
      label: 'Fichier',
      submenu: [
        {
          label: 'Tableau de bord',
          accelerator: 'CmdOrCtrl+1',
          click: () => mainWindow?.webContents.executeJavaScript("Router.navigate('dashboard')")
        },
        { type: 'separator' },
        isMac ? { role: 'close', label: 'Fermer la fenêtre' } : { role: 'quit', label: 'Quitter' }
      ]
    },

    // Menu Édition (standard OS)
    {
      label: 'Édition',
      submenu: [
        { role: 'undo', label: 'Annuler' },
        { role: 'redo', label: 'Rétablir' },
        { type: 'separator' },
        { role: 'cut', label: 'Couper' },
        { role: 'copy', label: 'Copier' },
        { role: 'paste', label: 'Coller' },
        { role: 'selectAll', label: 'Tout sélectionner' }
      ]
    },

    // Menu Affichage
    {
      label: 'Affichage',
      submenu: [
        { role: 'reload', label: 'Recharger' },
        { type: 'separator' },
        { role: 'resetZoom', label: 'Taille réelle' },
        { role: 'zoomIn', label: 'Zoom avant' },
        { role: 'zoomOut', label: 'Zoom arrière' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'Plein écran' }
      ]
    },

    // Menu Aide
    {
      label: 'Aide',
      submenu: [
        {
          label: 'À propos de SmartLife Pro',
          click: () => {
            const { dialog } = require('electron');
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'À propos',
              message: 'SmartLife Pro',
              detail: `Version : 1.0.0\n\nOrganisez votre vie, maîtrisez votre avenir.\n\nTous droits réservés © 2024`,
              buttons: ['OK'],
              icon: path.join(__dirname, 'assets', 'icon.png')
            });
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// ===== IPC HANDLERS =====
ipcMain.handle('get-version', () => app.getVersion());
ipcMain.handle('get-platform', () => process.platform);

// ===== CYCLE DE VIE APP =====
app.whenReady().then(() => {
  createWindow();
  buildMenu();

  // macOS : recréer la fenêtre si on clique sur l'icône dock
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

// Quitter sur toutes les plateformes (sauf macOS)
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Sécurité : bloquer la création de nouvelles fenêtres
app.on('web-contents-created', (event, contents) => {
  contents.on('new-window', (event) => {
    event.preventDefault();
  });
});
