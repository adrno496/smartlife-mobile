# ⚡ SmartLife Pro v1.0.0
> *Organisez votre vie, maîtrisez votre avenir.*

Application desktop 100% offline pour gérer vos tâches, habitudes, objectifs et budget personnel.

---

## 🚀 Installation en 3 étapes

```bash
# 1. Installer les dépendances
npm install

# 2. Lancer en développement
npm start

# 3. Builder l'installeur
npm run build:win    # Windows (.exe NSIS)
npm run build:mac    # macOS (.dmg)
npm run build:linux  # Linux (.AppImage)
```

---

## 📁 Structure du projet

```
smartlife-pro/
├── main.js        → Process principal Electron (fenêtre, menu, sécurité)
├── preload.js     → Bridge sécurisé contextBridge
├── index.html     → Shell SPA avec toutes les vues
├── style.css      → Design system dark premium complet
├── app.js         → Logique complète (tous modules)
├── package.json   → Config Electron Builder
└── assets/
    ├── icon.png   → 512×512px (requis pour build)
    └── icon.ico   → Pour Windows (requis pour build Windows)
```

---

## 🎨 Fonctionnalités

| Module | Description |
|--------|-------------|
| 🏠 **Dashboard** | Vue d'ensemble : tâches du jour, objectif, budget, score discipline |
| ✅ **To-Do List** | CRUD tâches avec priorités, filtres et tri |
| 🔥 **Habitudes** | Tracker quotidien avec streaks et score discipline |
| 🎯 **Objectifs** | Objectif principal avec sous-objectifs et barre de progression |
| 💰 **Budget** | Transactions, solde, répartition par catégorie |
| 📊 **Statistiques** | Métriques et graphes SVG inline sans dépendance |

---

## 💾 Stockage

Toutes les données sont stockées localement via `localStorage` :

| Clé | Contenu |
|-----|---------|
| `spl_tasks` | Tâches |
| `spl_habits` | Habitudes |
| `spl_habits_log` | Journal des habitudes |
| `spl_goals` | Objectif principal |
| `spl_budget` | Transactions budget |

---

## 🔐 Sécurité Electron

- `nodeIntegration: false`
- `contextIsolation: true`
- Content-Security-Policy strict
- Pas de navigation externe
- preload.js via `contextBridge`

---

## 📦 Build & Distribution

L'application peut être vendue sur **Gumroad**, **Lemon Squeezy** ou en direct.

- **Windows** : Installeur NSIS 32/64 bits
- **macOS** : Image disque DMG
- **Linux** : AppImage portable

---

## ⚠️ Assets requis pour le build

Avant de builder, créez le dossier `assets/` et ajoutez :
- `icon.png` — 512×512px PNG
- `icon.ico` — ICO multi-résolution (pour Windows)

Vous pouvez générer `icon.ico` depuis `icon.png` avec des outils comme ImageMagick ou des convertisseurs en ligne.

---

*SmartLife Pro — Tous droits réservés © 2024*
