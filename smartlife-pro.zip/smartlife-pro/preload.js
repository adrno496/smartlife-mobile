// ============================================================
// preload.js — SmartLife Pro — Bridge sécurisé contextBridge
// ============================================================

'use strict';

const { contextBridge, ipcRenderer } = require('electron');

// ===== EXPOSITION SÉCURISÉE DE L'API ELECTRON =====
// Seules les méthodes explicitement listées ici sont accessibles
// depuis le renderer (index.html / app.js).
// Node.js n'est PAS accessible directement dans le renderer.

contextBridge.exposeInMainWorld('electronAPI', {
  /**
   * Retourne la version de l'application
   * @returns {Promise<string>} ex: "1.0.0"
   */
  getVersion: () => ipcRenderer.invoke('get-version'),

  /**
   * Retourne la plateforme OS
   * @returns {Promise<string>} "win32" | "darwin" | "linux"
   */
  platform: () => ipcRenderer.invoke('get-platform')
});
